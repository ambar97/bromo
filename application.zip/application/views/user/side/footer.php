<section id="footer">
    <footer>
        <div class="row main-footer-sub">
            <div class="container clear-padding">
                <div class="col-md-7 col-sm-7">

                </div>
                <div class="col-md-5 col-sm-5">
                    <div class="social-media pull-right">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-footer row">
            <div class="container clear-padding">
                <div class="col-md-3 col-sm-6 about-box">
                    <h3>CRUISE</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    <a href="#">READ MORE</a>
                </div>
                <div class="clearfix visible-sm-block"></div>

                <div class="col-md-3 col-sm-6 contact-box">
                    <h4>Contact Us</h4>
                    <p><i class="fa fa-home"></i> Street #156 Burbank, Studio City Hollywood, California USA</p>
                    <p><i class="fa fa-phone"></i> +91 1234567890</p>
                    <p><i class="fa fa-envelope-o"></i> support@sunsetview.com</p>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12 text-center we-accept">

                </div>
            </div>
        </div>
        <div class="main-footer-nav row">
            <div class="container clear-padding">
                <div class="col-md-6 col-sm-6">
                    <p>Copyright &copy; 2019 SunsetView. All Rights Reserved.</p>
                </div>
                <div class="col-md-6 col-sm-6">

                </div>
                <div class="go-up">
                    <a href="#"><i class="fa fa-arrow-up"></i></a>
                </div>
            </div>
        </div>
    </footer>
</section>
<!-- END: FOOTER -->
</div>
