<script src="<?php echo base_url()?>master/assets/vendor/jquery/dist/jquery.min.js"></script>
   <script src="<?php echo base_url()?>master/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
   <script src="<?php echo base_url()?>master/assets/vendor/js-cookie/js.cookie.js"></script>
   <script src="<?php echo base_url()?>master/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
   <script src="<?php echo base_url()?>master/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
   <!-- Optional JS -->
   <script src="<?php echo base_url()?>master/assets/vendor/onscreen/dist/on-screen.umd.min.js"></script>
   <script src="<?php echo base_url()?>master/assets/js/argon.min9f1e.js?v=1.1.0"></script>
 </body>

 
<!-- Mirrored from demos.creative-tim.com/argon-dashboard-pro/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 22 Sep 2019 11:25:41 GMT -->
</html>