<script src="<?php echo base_url()?>master/assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo base_url()?>master/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url()?>master/assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="<?php echo base_url()?>master/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="<?php echo base_url()?>master/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="<?php echo base_url()?>master/assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="<?php echo base_url()?>master/assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <script type="text/javascript" src="<?php echo base_url()?>master/assets/vendor/fontawesome-f/js/all.min.js"></script>
  <script src="<?php echo base_url() ?>sweetalert/sweetalert.min.js"></script>
     <script src="<?php echo base_url() ?>sweetalert/jquery.sweet-alert.custom.js"></script>